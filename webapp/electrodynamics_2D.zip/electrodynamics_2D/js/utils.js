// 物理常量定义
const CONSTANTS = {
    e: 1.60217662e-19,
    me: 9.10938356e-31,
    mp: 1.6726219e-27,
    ma: 6.64465723e-27
};

// 粒子预设参数
const PRESETS = {
    electron: { q: -CONSTANTS.e, m: CONSTANTS.me, radius: 3, label: 'e⁻' },
    proton:   { q: CONSTANTS.e, m: CONSTANTS.mp, radius: 4, label: 'p⁺' },
    alpha:    { q: 2*CONSTANTS.e, m: CONSTANTS.ma, radius: 5, label: 'α²⁺' },
    custom:   { q: 1e-19, m: 1e-27, radius: 4, label: 'Custom' }
};

// 通用工具类
class Utils {
    static getRandomColor() {
        const h = Math.floor(Math.random() * 360);
        return `hsl(${h}, 90%, 60%)`;
    }

    static rotatePoint(x, y, cx, cy, angle) {
        const cos = Math.cos(angle);
        const sin = Math.sin(angle);
        const dx = x - cx;
        const dy = y - cy;
        return {
            x: cx + (dx * cos - dy * sin),
            y: cy + (dx * sin + dy * cos)
        };
    }
    
    static formatNumber(num) {
        if (Math.abs(num) < 1e-10) return "0";
        if (Math.abs(num) < 0.01 || Math.abs(num) >= 1000) return num.toExponential(1);
        return parseFloat(num.toPrecision(3)).toString();
    }
}