// 全局变量，便于调试
let app;

// 页面加载完成后启动应用
window.onload = () => {
    app = new SimulationApp();
};