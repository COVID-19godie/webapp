class SimulationApp {
    constructor() {
        this.canvas = document.getElementById('sim-canvas');
        this.ctx = this.canvas.getContext('2d');
        this.physics = new PhysicsEngine();
        
        this.scale = 2000; 
        this.offsetX = this.canvas.width / 2;
        this.offsetY = this.canvas.height / 2;
        this.isRunning = false;
        this.viewMode = 'cartesian';
        
        this.frameCount = 0;
        this.trailClearInterval = 50000;    

        // 场景状态
        this.currentSceneType = null;
        this.highlightedParticleId = null;
        
        // 选中对象状态 { type: 'particle'|'region', id: number }
        this.selectedObject = null;
        
        this.deleteHistory = [];

        this.isDragging = false;
        this.lastMouse = {x:0, y:0};

        this.initDOM();
        this.resize();
        this.animate();

        window.addEventListener('resize', () => this.resize());
        this.canvas.addEventListener('mousedown', e => this.onMouseDown(e));
        this.canvas.addEventListener('mousemove', e => this.onMouseMove(e));
        window.addEventListener('mouseup', () => this.isDragging = false);
        this.canvas.addEventListener('wheel', e => this.onWheel(e), {passive: false});
        
        window.addEventListener('keydown', e => {
            if(e.code === 'Space') this.toggleSim();
            if(e.code === 'KeyR') this.resetParticles();
            if((e.ctrlKey || e.metaKey) && e.code === 'KeyZ') {
                e.preventDefault();
                this.undoDelete();
            }
            if((e.ctrlKey || e.metaKey) && e.code === 'KeyX') {
                e.preventDefault();
                if(this.selectedObject) {
                    if(this.selectedObject.type === 'particle') {
                        this.deleteParticle(this.selectedObject.id);
                    } else if(this.selectedObject.type === 'region') {
                        this.deleteRegion(this.selectedObject.id);
                    }
                }
            }
        });
    }

    initDOM() {
        document.getElementById('btn-start').onclick = () => this.toggleSim();
        document.getElementById('btn-reset').onclick = () => this.resetParticles();
        document.getElementById('btn-view-reset').onclick = () => this.resetView(); 
        
        document.getElementById('btn-add-particle').onclick = () => this.addParticle();
        document.getElementById('btn-add-field').onclick = () => this.addField();
        
        document.getElementById('sim-speed').oninput = (e) => {
            const baseSteps = 100;
            this.physics.stepsPerFrame = baseSteps + parseInt(e.target.value) * 15;
        };
        
        document.getElementById('trail-interval').onchange = (e) => {
            this.trailClearInterval = parseInt(e.target.value);
        };

        this.toggleFieldInputs();
        this.toggleShapeInputs();
        this.toggleParticleInputMode();
        this.handlePresetChange();
    }

    switchTab(tabName) {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        if(tabName === 'controls') {
            document.querySelector('.tab-btn:nth-child(1)').classList.add('active');
            document.getElementById('tab-controls').classList.add('active');
        } else {
            document.querySelector('.tab-btn:nth-child(2)').classList.add('active');
            document.getElementById('tab-manage').classList.add('active');
            this.renderLists();
        }
    }

    // ====== 场景系统：UI生成与加载 ======

    setupSceneUI(type) {
        const panel = document.getElementById('scene-params-panel');
        const container = document.getElementById('scene-inputs');
        const title = document.getElementById('scene-title');
        
        panel.style.display = 'block';
        container.innerHTML = ''; 
        this.currentSceneType = type;

        let inputsHTML = '';

        if (type === 'velocity_selector') {
            title.innerText = "速度选择器参数";
            inputsHTML += this.createInput('sc-x', '起始中心 X (m)', -0.2, 0.01);
            inputsHTML += this.createInput('sc-y', '起始中心 Y (m)', 0, 0.01);
            
            inputsHTML += this.createInput('sc-v', '目标速度 (m/s)', 200000);
            inputsHTML += this.createInput('sc-b', '磁场 B (T)', 0.05, 0.001);
        } 
        else {
            if (type === 'dynamic_rotation') title.innerText = "旋转圆参数 (全屏场)";
            else if (type === 'dynamic_translation') title.innerText = "平移圆参数 (全屏场)";
            else if (type === 'dynamic_scaling') title.innerText = "放缩圆参数 (全屏场)";

            // --- 粒子数量输入 & 自动计算角度逻辑 ---
            let extraAttr = '';
            let defaultCount = 5;
            
            // 如果是旋转圆，添加联动逻辑：数量改变 -> 自动设置间隔为 360/N
            if (type === 'dynamic_rotation') {
                defaultCount = 12; // 默认 12 个粒子
                extraAttr = `oninput="if(this.value>0) document.getElementById('sc-step').value = parseFloat((360/this.value).toFixed(2))"`;
            }

            inputsHTML += this.createInput('sc-count', '粒子数量 (个)', defaultCount, 1, extraAttr);
            // ------------------------------------

            // 粒子源位置
            inputsHTML += this.createInput('sc-rho', '粒子源极径 ρ (m)', 0.1, 0.01);
            inputsHTML += this.createInput('sc-theta', '粒子源极角 θ (°)', 180, 1);

            inputsHTML += this.createInput('sc-v', '基准速度 (m/s)', 100000);
            inputsHTML += this.createInput('sc-b', '磁场 B (T)', 0.02, 0.001);
            
            if (type === 'dynamic_rotation') {
                // 默认 30度 = 360/12
                inputsHTML += this.createInput('sc-step', '角度间隔 (°)', 30);
            }
            else if (type === 'dynamic_translation') inputsHTML += this.createInput('sc-step', '间距间隔 (m)', 0.04, 0.01);
            else if (type === 'dynamic_scaling') inputsHTML += this.createInput('sc-step', '速度倍率增量', 0.2, 0.1);
        }

        container.innerHTML = inputsHTML;
        this.reloadCurrentScene();
    }

    createInput(id, label, val, step=null, extraAttr='') {
        return `
        <div class="input-row">
            <label>${label}:</label>
            <input type="number" id="${id}" value="${val}" ${step ? `step="${step}"` : ''} ${extraAttr}>
        </div>`;
    }

    reloadCurrentScene() {
        if (!this.currentSceneType) return;
        
        this.clearAll();
        this.isRunning = false;
        document.getElementById('status-state').innerText = "状态: 停止";
        
        const getVal = (id) => parseFloat(document.getElementById(id).value);
        
        const type = this.currentSceneType;
        const proton = PRESETS.proton;
        const rectW_Selector = 0.4, rectH_Selector = 0.2;
        // 扩充颜色库
        const colors = ['#FF5252', '#FFEB3B', '#448AFF', '#69F0AE', '#E040FB', '#FF9800', '#00BCD4', '#9C27B0'];
        
        let startX, startY;
        if (type === 'velocity_selector') {
            startX = getVal('sc-x');
            startY = getVal('sc-y');
            const v = getVal('sc-v');
            const B = getVal('sc-b');
            const E = v * B; 

            const centerX = startX + rectW_Selector / 2;
            const centerY = 0;

            const magRegion = new RectRegion(this.physics.nextId++, 'magnetic', centerX, centerY, rectW_Selector, rectH_Selector, 0);
            magRegion.Bz = -B; 
            this.physics.addRegion(magRegion);

            const elecRegion = new RectRegion(this.physics.nextId++, 'electric', centerX, centerY, rectW_Selector, rectH_Selector, 0);
            elecRegion.Ex = 0;
            elecRegion.Ey = -E; 
            this.physics.addRegion(elecRegion);

            const p = new Particle(this.physics.nextId++, startX, startY, v, 0, proton, '#FF9800');
            p.label = "v=E/B";
            this.physics.addParticle(p);

            const pFast = new Particle(this.physics.nextId++, startX, startY + 0.02, v*1.5, 0, proton, '#9E9E9E');
            pFast.label = "v_high";
            this.physics.addParticle(pFast);

             const pSlow = new Particle(this.physics.nextId++, startX, startY - 0.02, v*0.7, 0, proton, '#607D8B');
            pSlow.label = "v_low";
            this.physics.addParticle(pSlow);
        }
        else {
            const rho = getVal('sc-rho');
            const theta = getVal('sc-theta') * Math.PI / 180;
            startX = rho * Math.cos(theta);
            startY = rho * Math.sin(theta);

            const vBase = getVal('sc-v');
            const B = getVal('sc-b');
            const step = getVal('sc-step');
            
            // --- 获取粒子数量 ---
            let count = parseInt(document.getElementById('sc-count').value);
            if (isNaN(count) || count < 1) count = 1;

            // 使用全屏场
            const fieldR = new UniformRegion(this.physics.nextId++, 'magnetic');
            fieldR.Bz = -B; 
            this.physics.addRegion(fieldR);

            // 循环生成粒子
            for (let i = 0; i < count; i++) {
                // 计算对称偏差因子
                const offsetFactor = i - (count - 1) / 2;
                const color = colors[i % colors.length];

                if (type === 'dynamic_rotation') {
                    const angleDeg = offsetFactor * step;
                    const rad = angleDeg * Math.PI / 180;
                    const vx = vBase * Math.cos(rad);
                    const vy = vBase * Math.sin(rad);
                    
                    const p = new Particle(this.physics.nextId++, startX, startY, vx, vy, proton, color);
                    p.label = `${Math.round(angleDeg)}°`;
                    this.physics.addParticle(p);
                }
                else if (type === 'dynamic_translation') {
                    const yOffset = -offsetFactor * step; 
                    const p = new Particle(this.physics.nextId++, startX, startY + yOffset, vBase, 0, proton, color);
                    p.label = `y${yOffset > 0 ? '+' : ''}${parseFloat(yOffset.toFixed(3))}`;
                    this.physics.addParticle(p);
                }
                else if (type === 'dynamic_scaling') {
                    const factor = 1 + offsetFactor * step;
                    if(factor <= 0) continue;
                    
                    const v = vBase * factor;
                    const p = new Particle(this.physics.nextId++, startX, startY, v, 0, proton, color);
                    p.label = `v×${factor.toFixed(2)}`;
                    this.physics.addParticle(p);
                }
            }
        }

        this.renderLists();
        this.scale = 1500;
        this.draw();
    }

    // ====== 编辑器功能 ======

    selectObject(type, id) {
        this.selectedObject = { type, id };
        this.highlightedParticleId = (type === 'particle') ? id : null;
        this.renderEditor();
        this.draw(); 
    }

    closeEditor() {
        this.selectedObject = null;
        this.highlightedParticleId = null;
        document.getElementById('editor-panel').style.display = 'none';
        this.draw();
    }

    renderEditor() {
        const panel = document.getElementById('editor-panel');
        const container = document.getElementById('editor-inputs');
        const titleId = document.getElementById('editor-id');
        
        if (!this.selectedObject) {
            panel.style.display = 'none';
            return;
        }

        const { type, id } = this.selectedObject;
        let obj = null;

        if (type === 'particle') {
            obj = this.physics.particles.find(p => p.id === id);
        } else {
            obj = this.physics.regions.find(r => r.id === id);
        }

        if (!obj) {
            this.closeEditor();
            return;
        }

        panel.style.display = 'block';
        titleId.innerText = `(ID: ${id} - ${type === 'particle' ? '粒子' : '场'})`;
        
        let html = '';

        if (type === 'particle') {
            html += this.createEditorInput('Label', 'text', obj.label, 'p-edit-label');
            html += this.createEditorInput('颜色', 'color', obj.color, 'p-edit-color');
            html += this.createEditorInput('电荷 q (C)', 'number', obj.q, 'p-edit-q', 'step="1e-20"');
            html += this.createEditorInput('质量 m (kg)', 'number', obj.m, 'p-edit-m', 'step="1e-28"');
            html += this.createEditorInput('半径 (px)', 'number', obj.radius, 'p-edit-r');
            
            html += `<div style="margin:5px 0; border-top:1px dashed #ccc; padding-top:5px; font-size:12px; font-weight:bold; color:#666;">速度矢量</div>`;
            html += this.createEditorInput('Vx (m/s)', 'number', obj.vel.x, 'p-edit-vx', 'step="100"');
            html += this.createEditorInput('Vy (m/s)', 'number', obj.vel.y, 'p-edit-vy', 'step="100"');
        } 
        else if (type === 'region') {
            if (obj.type === 'magnetic') {
                html += this.createEditorInput('磁感应强度 Bz (T)', 'number', obj.Bz, 'r-edit-bz', 'step="0.001"');
            } else {
                html += this.createEditorInput('电场 Ex (V/m)', 'number', obj.Ex, 'r-edit-ex', 'step="100"');
                html += this.createEditorInput('电场 Ey (V/m)', 'number', obj.Ey, 'r-edit-ey', 'step="100"');
            }

            if (obj.shape !== 'uniform') {
                html += `<div style="margin:5px 0; border-top:1px dashed #ccc; padding-top:5px; font-size:12px; font-weight:bold; color:#666;">几何参数</div>`;
                html += this.createEditorInput('中心 X (m)', 'number', obj.cx, 'r-edit-cx', 'step="0.01"');
                html += this.createEditorInput('中心 Y (m)', 'number', obj.cy, 'r-edit-cy', 'step="0.01"');
                
                if (obj.shape === 'rect') {
                    html += this.createEditorInput('宽度 W (m)', 'number', obj.w, 'r-edit-w', 'step="0.01"');
                    html += this.createEditorInput('高度 H (m)', 'number', obj.h, 'r-edit-h', 'step="0.01"');
                    html += this.createEditorInput('旋转角度 (rad)', 'number', obj.angle, 'r-edit-angle', 'step="0.1"');
                } else if (obj.shape === 'circle') {
                    html += this.createEditorInput('半径 R (m)', 'number', obj.r, 'r-edit-r', 'step="0.01"');
                }
            }
        }

        container.innerHTML = html;

        const inputs = container.querySelectorAll('input');
        inputs.forEach(input => {
            input.onchange = (e) => this.applyEditorChange(type, id, e.target.id, e.target.value);
            if(input.type === 'color') {
                 input.oninput = (e) => this.applyEditorChange(type, id, e.target.id, e.target.value);
            }
        });
    }

    createEditorInput(label, type, val, id, extras='') {
        return `
        <div class="input-row">
            <label style="flex:2">${label}:</label>
            <input type="${type}" id="${id}" value="${val}" style="flex:3" ${extras}>
        </div>`;
    }

    applyEditorChange(type, id, inputId, val) {
        let obj;
        if (type === 'particle') obj = this.physics.particles.find(p => p.id === id);
        else obj = this.physics.regions.find(r => r.id === id);
        
        if (!obj) return;

        const numVal = parseFloat(val);

        if (type === 'particle') {
            switch(inputId) {
                case 'p-edit-label': obj.label = val; break;
                case 'p-edit-color': obj.color = val; break;
                case 'p-edit-q': obj.q = numVal; break;
                case 'p-edit-m': obj.m = numVal; break;
                case 'p-edit-r': obj.radius = numVal; break;
                case 'p-edit-vx': obj.vel.x = numVal; break;
                case 'p-edit-vy': obj.vel.y = numVal; break;
            }
            this.updateMonitor();
        } 
        else if (type === 'region') {
            switch(inputId) {
                case 'r-edit-bz': obj.Bz = numVal; break;
                case 'r-edit-ex': obj.Ex = numVal; break;
                case 'r-edit-ey': obj.Ey = numVal; break;
                case 'r-edit-cx': obj.cx = numVal; break;
                case 'r-edit-cy': obj.cy = numVal; break;
                case 'r-edit-w': obj.w = numVal; break;
                case 'r-edit-h': obj.h = numVal; break;
                case 'r-edit-angle': obj.angle = numVal; break;
                case 'r-edit-r': obj.r = numVal; break;
            }
            this.renderLists();
        }
        this.draw();
    }

    // ====== 视图与其他功能 ======

    changeViewMode(mode) {
        this.viewMode = mode;
        this.draw();
    }

    toggleParticleInputMode() {
        const mode = document.getElementById('p-pos-mode').value;
        document.getElementById('p-input-cartesian').style.display = mode === 'cartesian' ? 'block' : 'none';
        document.getElementById('p-input-polar').style.display = mode === 'polar' ? 'block' : 'none';
    }

    toggleFieldInputs() {
        const isMag = document.getElementById('field-type').value === 'magnetic';
        document.getElementById('magnetic-inputs').style.display = isMag ? 'block' : 'none';
        document.getElementById('electric-inputs').style.display = isMag ? 'none' : 'block';
    }

    toggleShapeInputs() {
        const shape = document.getElementById('region-shape').value;
        document.querySelectorAll('.dynamic-input-group').forEach(el => el.classList.remove('active'));
        this.handlePresetChange();
        
        if (shape !== 'uniform') {
            document.getElementById(`shape-${shape}`).classList.add('active');
        }
    }

    resize() {
        this.canvas.width = document.getElementById('main-area').clientWidth;
        this.canvas.height = document.getElementById('main-area').clientHeight;
        if (!this.offsetX) this.resetView(); 
    }

    resetView() {
        this.scale = 2000;
        this.offsetX = this.canvas.width / 2;
        this.offsetY = this.canvas.height / 2;
        this.draw();
    }

    w2s(wx, wy) {
        return { x: wx * this.scale + this.offsetX, y: this.offsetY - wy * this.scale };
    }
    s2w(sx, sy) {
        return { x: (sx - this.offsetX) / this.scale, y: (this.offsetY - sy) / this.scale };
    }

    toggleSim() {
        this.isRunning = !this.isRunning;
        document.getElementById('status-state').innerText = this.isRunning ? "状态: 运行中" : "状态: 停止";
    }

    resetParticles() {
        this.physics.particles = [];
        this.highlightedParticleId = null;
        this.selectedObject = null;
        this.frameCount = 0;
        this.renderLists();
        this.updateMonitor();
        document.getElementById('editor-panel').style.display = 'none';
        this.draw();
    }

    clearAll() {
        this.physics.particles = [];
        this.physics.regions = [];
        this.highlightedParticleId = null;
        this.selectedObject = null;
        this.deleteHistory = [];
        this.frameCount = 0;
        this.renderLists();
        this.updateMonitor();
        document.getElementById('editor-panel').style.display = 'none';
        this.draw();
    }

    handlePresetChange() {
        const name = document.getElementById('particle-preset').value;
        const customProps = document.getElementById('custom-particle-props');
        if (name === 'custom') {
            customProps.classList.add('active');
        } else {
            customProps.classList.remove('active');
        }
        this.loadPreset(name);
    }

    loadPreset(name) {
        if (name === 'custom') return;
        let v0 = 2e6;
        if (name === 'proton') v0 = 5e4;
        if (name === 'alpha') v0 = 3e4;
        document.getElementById('p-velocity').value = v0;
    }

    addParticle() {
        const type = document.getElementById('particle-preset').value;
        let config = PRESETS[type];
        
        if (type === 'custom') {
             const qVal = parseFloat(document.getElementById('custom-q').value);
             const mVal = parseFloat(document.getElementById('custom-m').value);
             config = {
                 q: qVal,
                 m: mVal,
                 radius: 4,
                 label: 'Custom'
             };
        }
        
        const v0 = parseFloat(document.getElementById('p-velocity').value);
        const angleV = parseFloat(document.getElementById('p-angle').value) * Math.PI / 180;
        
        let x, y;
        const inputMode = document.getElementById('p-pos-mode').value;
        
        if (inputMode === 'cartesian') {
            x = parseFloat(document.getElementById('p-x').value);
            y = parseFloat(document.getElementById('p-y').value);
        } else {
            const rho = parseFloat(document.getElementById('p-rho').value);
            const theta = parseFloat(document.getElementById('p-theta').value) * Math.PI / 180;
            x = rho * Math.cos(theta);
            y = rho * Math.sin(theta);
        }

        const vx = v0 * Math.cos(angleV);
        const vy = v0 * Math.sin(angleV);

        let color = '#2196F3';
        if (type === 'proton') color = '#FF9800';
        else if (type === 'alpha') color = '#4CAF50';
        else if (type === 'custom') color = Utils.getRandomColor();

        const p = new Particle(this.physics.nextId++, x, y, vx, vy, config, color);
        this.physics.addParticle(p);
        this.renderLists();
        this.updateMonitor();

        this.isRunning = false;
        document.getElementById('status-state').innerText = "状态: 停止";
        this.draw(); 
    }

    addField() {
        const type = document.getElementById('field-type').value;
        const shape = document.getElementById('region-shape').value;
        
        let props = {};
        if (type === 'magnetic') {
            props.Bz = parseFloat(document.getElementById('field-b').value);
            if (document.getElementById('field-b-dir').value === 'in') props.Bz *= -1;
        } else {
            props.Ex = parseFloat(document.getElementById('field-ex').value);
            props.Ey = parseFloat(document.getElementById('field-ey').value);
        }

        let region;
        const id = this.physics.nextId++;

        if (shape === 'uniform') {
            region = new UniformRegion(id, type);
        } else if (shape === 'rect') {
            const cx = parseFloat(document.getElementById('rect-x').value);
            const cy = parseFloat(document.getElementById('rect-y').value);
            const w = parseFloat(document.getElementById('rect-w').value);
            const h = parseFloat(document.getElementById('rect-h').value);
            const angle = parseFloat(document.getElementById('rect-angle').value) * Math.PI / 180;
            region = new RectRegion(id, type, cx, cy, w, h, angle);
        } else if (shape === 'circle') {
            const cx = parseFloat(document.getElementById('circ-x').value);
            const cy = parseFloat(document.getElementById('circ-y').value);
            const r = parseFloat(document.getElementById('circ-r').value);
            region = new CircleRegion(id, type, cx, cy, r);
        }

        if (region) {
            Object.assign(region, props);
            this.physics.addRegion(region);
            this.renderLists();
        }

        this.isRunning = false;
        document.getElementById('status-state').innerText = "状态: 停止";
        this.draw(); 
    }

    renderLists() {
        const fList = document.getElementById('field-list-container');
        const pList = document.getElementById('particle-list-container');
        
        if (this.physics.regions.length === 0) fList.innerHTML = '<div style="color:#999;font-size:12px;padding:10px;">无场区域</div>';
        else {
            fList.innerHTML = this.physics.regions.map(r => {
                let info = r.type === 'magnetic' ? `B=${r.Bz}T` : `E=(${r.Ex},${r.Ey})`;
                let shapeName = { rect:'矩形', circle:'圆形', uniform:'全空间' }[r.shape];
                
                const isSelected = (this.selectedObject && this.selectedObject.type === 'region' && this.selectedObject.id === r.id);
                const bgStyle = isSelected ? 'background-color:#ffe082;' : '';

                return `
                <div id="list-item-region-${r.id}" class="list-item field-item" style="cursor:pointer; ${bgStyle}"
                     onclick="app.selectObject('region', ${r.id})">
                    <span>${shapeName} [${info}]</span>
                    <button class="delete-btn" onclick="event.stopPropagation(); app.deleteRegion(${r.id})">×</button>
                </div>`;
            }).join('');
        }

        if (this.physics.particles.length === 0) pList.innerHTML = '<div style="color:#999;font-size:12px;padding:10px;">无粒子</div>';
        else {
            pList.innerHTML = this.physics.particles.map(p => `
                <div id="list-item-particle-${p.id}" class="list-item particle-item" style="border-left-color:${p.color}">
                    <span>${p.label}</span>
                    <button class="delete-btn" onclick="app.deleteParticle(${p.id})">×</button>
                </div>
            `).join('');
        }
    }

    deleteParticle(id) {
        const p = this.physics.particles.find(p => p.id === id);
        if (p) {
            this.deleteHistory.push({
                type: 'particle',
                data: JSON.parse(JSON.stringify({
                    id: p.id,
                    pos: p.pos,
                    vel: p.vel,
                    q: p.q,
                    m: p.m,
                    radius: p.radius,
                    label: p.label,
                    color: p.color,
                    trail: p.trail,
                    active: p.active
                }))
            });
        }
        
        this.physics.removeParticle(id);
        if (this.highlightedParticleId === id) this.highlightedParticleId = null;
        if (this.selectedObject && this.selectedObject.type === 'particle' && this.selectedObject.id === id) {
            this.closeEditor();
        }
        this.renderLists();
        this.updateMonitor();
    }
    deleteRegion(id) {
        const r = this.physics.regions.find(r => r.id === id);
        if (r) {
            const regionData = {
                id: r.id,
                type: r.type,
                shape: r.shape
            };
            
            if (r.type === 'magnetic') {
                regionData.Bz = r.Bz;
            } else if (r.type === 'electric') {
                regionData.Ex = r.Ex;
                regionData.Ey = r.Ey;
            }
            
            if (r.shape === 'rect') {
                regionData.cx = r.cx;
                regionData.cy = r.cy;
                regionData.w = r.w;
                regionData.h = r.h;
                regionData.angle = r.angle;
            } else if (r.shape === 'circle') {
                regionData.cx = r.cx;
                regionData.cy = r.cy;
                regionData.r = r.r;
            }
            
            this.deleteHistory.push({
                type: 'region',
                data: regionData
            });
        }
        
        this.physics.removeRegion(id);
        if (this.selectedObject && this.selectedObject.type === 'region' && this.selectedObject.id === id) {
            this.closeEditor();
        }
        this.renderLists();
        this.draw();
    }

    undoDelete() {
        if (this.deleteHistory.length === 0) return;

        const lastDeleted = this.deleteHistory.pop();

        if (lastDeleted.type === 'particle') {
            const d = lastDeleted.data;
            const config = {
                q: d.q,
                m: d.m,
                radius: d.radius,
                label: d.label
            };
            const p = new Particle(d.id, d.pos.x, d.pos.y, d.vel.x, d.vel.y, config, d.color);
            p.trail = d.trail;
            p.active = d.active;
            this.physics.addParticle(p);
        } else if (lastDeleted.type === 'region') {
            const d = lastDeleted.data;
            let r;
            if (d.shape === 'rect') {
                r = new RectRegion(d.id, d.type, d.cx, d.cy, d.w, d.h, d.angle);
            } else if (d.shape === 'circle') {
                r = new CircleRegion(d.id, d.type, d.cx, d.cy, d.r);
            } else if (d.shape === 'uniform') {
                r = new UniformRegion(d.id, d.type);
            }

            if (d.type === 'magnetic') {
                r.Bz = d.Bz;
            } else if (d.type === 'electric') {
                r.Ex = d.Ex;
                r.Ey = d.Ey;
            }

            this.physics.addRegion(r);
        }

        this.renderLists();
        this.updateMonitor();
        this.draw();
    }
    
    highlightParticle(id) {
        this.highlightedParticleId = id;
        this.draw();
        setTimeout(() => {
             // 只有当没有被选中编辑时才自动取消高亮
             if (!this.selectedObject || this.selectedObject.id !== id) {
                 this.highlightedParticleId = null; 
                 this.draw();
             }
        }, 800);
    }

    updateMonitor() {
        const container = document.getElementById('monitor-container');
        
        if (this.physics.particles.length === 0) {
            if (container.innerHTML.indexOf("暂无活跃粒子") === -1) {
                container.innerHTML = '<div style="color:#999; font-size:12px; padding:10px;">暂无活跃粒子</div>';
            }
            return;
        }

        let html = '';
        
        this.physics.particles.forEach(p => {
            const res = this.physics.acceleration(p.pos.x, p.pos.y, p.vel.x, p.vel.y, p.q, p.m);
            const v = Math.hypot(p.vel.x, p.vel.y);
            
            const isSelected = (this.selectedObject && this.selectedObject.type === 'particle' && this.selectedObject.id === p.id);
            const activeClass = isSelected ? 'border: 2px solid #FF9800; background: #37474F;' : '';

            html += `
            <div class="monitor-card" style="border-left-color: ${p.color}; ${activeClass}" 
                 onclick="app.switchTab('manage'); app.selectObject('particle', ${p.id})">
                <div class="monitor-header">
                    <span>${p.label} <span style="font-weight:normal; font-size:10px; opacity:0.7">ID:${p.id}</span></span>
                    <button class="mini-del-btn" onclick="event.stopPropagation(); app.deleteParticle(${p.id})">×</button>
                </div>
                <div class="monitor-data">
                    <span>x: <span class="val">${p.pos.x.toExponential(2)}</span></span>
                    <span>vx: <span class="val">${p.vel.x.toExponential(2)}</span></span>
                    <span>y: <span class="val">${p.pos.y.toExponential(2)}</span></span>
                    <span>vy: <span class="val">${p.vel.y.toExponential(2)}</span></span>
                    <span>v: <span class="val">${v.toExponential(2)}</span></span>
                    <span>B: <span class="val">${res.fields.Bz.toFixed(3)}</span></span>
                </div>
            </div>`;
        });
        
        container.innerHTML = html;
    }

    animate() {
        if (this.isRunning) {
            for(let i=0; i<this.physics.stepsPerFrame; i++) {
                this.physics.step();
            }
            if (this.frameCount % 5 === 0) {
                this.updateMonitor();
            }
            this.frameCount++;
            if (this.frameCount >= this.trailClearInterval) {
                this.frameCount = 0;
                this.physics.particles.forEach(p => {
                    p.trail = [{x: p.pos.x, y: p.pos.y}];
                });
            }
        }
        
        this.draw();
        requestAnimationFrame(() => this.animate());
    }

    draw() {
        const ctx = this.ctx;
        ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        if (this.viewMode === 'cartesian') {
            this.drawCartesianGrid(ctx);
        } else {
            this.drawPolarGrid(ctx);
        }

        this.drawRegions(ctx);
        this.drawParticles(ctx);
    }

    drawCartesianGrid(ctx) {
        ctx.strokeStyle = '#e0e0e0';
        ctx.lineWidth = 1;
        ctx.fillStyle = "#666";
        ctx.font = "10px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "top";
        ctx.setLineDash([]); 
        
        let gridSize = 0.1; 
        while (gridSize * this.scale < 50) gridSize *= 10;
        while (gridSize * this.scale > 200) gridSize /= 10;

        const tl = this.s2w(0, 0);
        const br = this.s2w(this.canvas.width, this.canvas.height);

        const startX = Math.floor(tl.x / gridSize) * gridSize;
        const endX = Math.ceil(br.x / gridSize) * gridSize;
        const startY = Math.floor(br.y / gridSize) * gridSize; 
        const endY = Math.ceil(tl.y / gridSize) * gridSize;

        const origin = this.w2s(0, 0);

        ctx.beginPath();
        for (let x = startX; x <= endX; x += gridSize) {
            const s = this.w2s(x, 0);
            ctx.moveTo(s.x, 0);
            ctx.lineTo(s.x, this.canvas.height);
            
            if (Math.abs(x) > 1e-10) { 
                ctx.fillText(Utils.formatNumber(x), s.x, origin.y + 4);
                ctx.moveTo(s.x, origin.y);
                ctx.lineTo(s.x, origin.y + 4);
            }
        }
        ctx.stroke();

        ctx.textAlign = "right";
        ctx.textBaseline = "middle";
        ctx.beginPath();
        const minY = Math.min(startY, endY), maxY = Math.max(startY, endY);
        for (let y = minY; y <= maxY; y += gridSize) {
            const s = this.w2s(0, y);
            ctx.moveTo(0, s.y);
            ctx.lineTo(this.canvas.width, s.y);

            if (Math.abs(y) > 1e-10) { 
                ctx.fillText(Utils.formatNumber(y), origin.x - 4, s.y);
                ctx.moveTo(origin.x, s.y);
                ctx.lineTo(origin.x - 4, s.y);
            }
        }
        ctx.stroke();

        ctx.strokeStyle = '#999';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, origin.y);
        ctx.lineTo(this.canvas.width, origin.y);
        ctx.moveTo(origin.x, 0);
        ctx.lineTo(origin.x, this.canvas.height);
        ctx.stroke();

        ctx.fillText("0", origin.x - 4, origin.y + 4);
    }

    drawPolarGrid(ctx) {
        ctx.strokeStyle = '#e0e0e0';
        ctx.lineWidth = 1;
        ctx.fillStyle = "#888";
        ctx.font = "10px sans-serif";
        ctx.setLineDash([]); 

        const origin = this.w2s(0, 0);
        const maxR = Math.max(this.canvas.width, this.canvas.height) / this.scale * 1.5;

        let rStep = 0.1;
        while (rStep * this.scale < 50) rStep *= 10;
        while (rStep * this.scale > 200) rStep /= 10;

        ctx.beginPath();
        ctx.textAlign = "left";
        ctx.textBaseline = "bottom";
        for (let r = rStep; r < maxR; r += rStep) {
            const screenR = r * this.scale;
            ctx.moveTo(origin.x + screenR, origin.y);
            ctx.arc(origin.x, origin.y, screenR, 0, Math.PI * 2);
            ctx.fillText(Utils.formatNumber(r), origin.x + screenR + 2, origin.y - 2);
        }
        ctx.stroke();

        ctx.beginPath();
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const maxScreenDim = Math.max(this.canvas.width, this.canvas.height);
        for (let ang = 0; ang < 360; ang += 30) {
            const rad = ang * Math.PI / 180;
            const endX = origin.x + Math.cos(rad) * maxScreenDim * 2;
            const endY = origin.y - Math.sin(rad) * maxScreenDim * 2;
            
            ctx.moveTo(origin.x, origin.y);
            ctx.lineTo(endX, endY);

            const textR = Math.min(this.canvas.width, this.canvas.height) * 0.45;
            const tx = origin.x + Math.cos(rad) * textR;
            const ty = origin.y - Math.sin(rad) * textR;
            ctx.fillText(ang + "°", tx, ty);
        }
        ctx.stroke();

        ctx.fillStyle = '#666';
        ctx.beginPath();
        ctx.arc(origin.x, origin.y, 3, 0, Math.PI*2);
        ctx.fill();
    }

    drawRegions(ctx) {
        ctx.setLineDash([]); 
        for (let r of this.physics.regions) {
            ctx.save();
            ctx.fillStyle = r.type === 'magnetic' ? 'rgba(33, 150, 243, 0.2)' : 'rgba(255, 193, 7, 0.2)';
            
            // 选中效果
            const isSelected = (this.selectedObject && this.selectedObject.type === 'region' && this.selectedObject.id === r.id);
            if (isSelected) {
                ctx.strokeStyle = '#FF5722';
                ctx.lineWidth = 4;
            } else {
                ctx.strokeStyle = r.type === 'magnetic' ? '#2196F3' : '#FFC107';
                ctx.lineWidth = 2;
            }

            if (r.shape === 'uniform') {
                ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
            } 
            else if (r.shape === 'rect') {
                const center = this.w2s(r.cx, r.cy);
                ctx.translate(center.x, center.y);
                ctx.rotate(r.angle); 
                ctx.beginPath();
                ctx.rect(-r.w * this.scale / 2, -r.h * this.scale / 2, r.w * this.scale, r.h * this.scale);
                ctx.fill();
                ctx.stroke();
                ctx.rotate(-r.angle);
                this.drawFieldSymbol(ctx, 0, 0, r);
            } 
            else if (r.shape === 'circle') {
                const center = this.w2s(r.cx, r.cy);
                ctx.beginPath();
                ctx.arc(center.x, center.y, r.r * this.scale, 0, Math.PI*2);
                ctx.fill();
                ctx.stroke();
                this.drawFieldSymbol(ctx, center.x, center.y, r);
            }
            ctx.restore();
        }
    }

    drawFieldSymbol(ctx, x, y, r) {
        ctx.fillStyle = ctx.strokeStyle;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        let symbol = "E";
        if (r.type === 'magnetic') symbol = r.Bz < 0 ? "×" : "•"; 
        ctx.font = "16px Arial";
        ctx.fillText(symbol, x, y);
    }

    drawParticles(ctx) {
        for (let p of this.physics.particles) {
            if (p.trail.length > 1) {
                ctx.beginPath();
                ctx.strokeStyle = p.color;
                ctx.lineWidth = 2;
                ctx.setLineDash([4, 4]); 
                ctx.globalAlpha = 0.6;
                for (let i = 0; i < p.trail.length; i++) {
                    const pos = this.w2s(p.trail[i].x, p.trail[i].y);
                    if (i === 0) ctx.moveTo(pos.x, pos.y);
                    else ctx.lineTo(pos.x, pos.y);
                }
                ctx.stroke();
                ctx.globalAlpha = 1.0;
                ctx.setLineDash([]);
            }

            const pos = this.w2s(p.pos.x, p.pos.y);
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, p.radius, 0, Math.PI*2);
            ctx.fillStyle = p.color;
            ctx.fill();

            // 选中或高亮效果
            if (this.highlightedParticleId === p.id || (this.selectedObject && this.selectedObject.type === 'particle' && this.selectedObject.id === p.id)) {
                ctx.beginPath();
                ctx.arc(pos.x, pos.y, p.radius * 2.5 + 4, 0, Math.PI*2);
                ctx.strokeStyle = this.selectedObject && this.selectedObject.id === p.id ? '#FF5722' : '#FFEB3B';
                ctx.lineWidth = 2;
                if (this.selectedObject && this.selectedObject.id === p.id) ctx.setLineDash([2, 2]);
                ctx.stroke();
                ctx.setLineDash([]);
            }

            const vMag = Math.hypot(p.vel.x, p.vel.y);
            if (vMag > 1e-10) {
                const arrowLen = 35; 
                const angle = Math.atan2(-p.vel.y, p.vel.x); 
                
                const endX = pos.x + Math.cos(angle) * arrowLen;
                const endY = pos.y + Math.sin(angle) * arrowLen;

                ctx.beginPath();
                ctx.moveTo(pos.x, pos.y);
                ctx.lineTo(endX, endY);
                ctx.strokeStyle = '#455A64';
                ctx.lineWidth = 1.5;
                ctx.stroke();

                const headLen = 8;
                ctx.beginPath();
                ctx.moveTo(endX, endY);
                ctx.lineTo(endX - headLen * Math.cos(angle - Math.PI/6), endY - headLen * Math.sin(angle - Math.PI/6));
                ctx.lineTo(endX - headLen * Math.cos(angle + Math.PI/6), endY - headLen * Math.sin(angle + Math.PI/6));
                ctx.fillStyle = '#455A64';
                ctx.fill();
            }
        }
    }

    onMouseDown(e) {
        this.isDragging = true;
        this.lastMouse = { x: e.clientX, y: e.clientY };

        const rect = this.canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left;
        const my = e.clientY - rect.top;
        const wPos = this.s2w(mx, my);

        // 优先检测粒子点击
        let clickedParticle = null;
        const clickThreshold = 10 / this.scale; 
        for (let p of this.physics.particles) {
            const dist = Math.hypot(p.pos.x - wPos.x, p.pos.y - wPos.y);
            const pRadiusPhys = p.radius / this.scale; 
            if (dist < Math.max(pRadiusPhys, clickThreshold)) {
                clickedParticle = p;
                break;
            }
        }

        if (clickedParticle) {
            this.switchTab('manage'); 
            this.selectObject('particle', clickedParticle.id);
            return;
        }

        // 检测场区域点击
        let clickedRegionId = null;
        for (let i = this.physics.regions.length - 1; i >= 0; i--) {
            const r = this.physics.regions[i];
            if (r.contains(wPos.x, wPos.y)) {
                clickedRegionId = r.id;
                break;
            }
        }

        if (clickedRegionId !== null) {
            this.switchTab('manage');
            this.selectObject('region', clickedRegionId);
        }
    }

    onMouseMove(e) {
        const rect = this.canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left;
        const my = e.clientY - rect.top;
        const wPos = this.s2w(mx, my);

        let coordText = "";
        const r = Math.hypot(wPos.x, wPos.y);
        let theta = Math.atan2(wPos.y, wPos.x) * 180 / Math.PI;
        if (theta < 0) theta += 360;

        if (this.viewMode === 'cartesian') {
            coordText = `(x=${wPos.x.toFixed(3)}, y=${wPos.y.toFixed(3)})`;
        } else {
            coordText = `(ρ=${r.toFixed(3)}, θ=${theta.toFixed(1)}°)`;
        }
        document.getElementById('status-mouse').innerText = `鼠标: ${coordText}`;

        if (this.isDragging) {
            const dx = e.clientX - this.lastMouse.x;
            const dy = e.clientY - this.lastMouse.y;
            this.offsetX += dx;
            this.offsetY += dy;
            this.lastMouse = { x: e.clientX, y: e.clientY };
            this.draw(); 
        }
    }

    onWheel(e) {
        e.preventDefault();
        const zoomRate = 0.1;
        const delta = e.deltaY > 0 ? (1 - zoomRate) : (1 + zoomRate);
        
        const rect = this.canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left;
        const my = e.clientY - rect.top;
        const worldBefore = this.s2w(mx, my);

        this.scale *= delta;
        this.scale = Math.max(1, Math.min(this.scale, 1e8));

        this.offsetX = mx - worldBefore.x * this.scale;
        this.offsetY = my + worldBefore.y * this.scale;

        const unit = this.scale;
        document.getElementById('status-scale').innerText = `比例: 1px ≈ ${(1/unit).toExponential(1)}m`;
        
        this.draw();
    }
}