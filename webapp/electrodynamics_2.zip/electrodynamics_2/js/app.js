class SimulationApp {
    constructor() {
        this.canvas = document.getElementById('sim-canvas');
        this.ctx = this.canvas.getContext('2d');
        this.physics = new PhysicsEngine();
        
        this.scale = 2000; 
        this.offsetX = this.canvas.width / 2;
        this.offsetY = this.canvas.height / 2;
        this.isRunning = false;
        this.viewMode = 'cartesian';
        
        this.frameCount = 0;
        this.trailClearInterval = 50000; 

        // 场景状态
        this.currentSceneType = null;
        this.highlightedParticleId = null;

        this.isDragging = false;
        this.lastMouse = {x:0, y:0};

        this.initDOM();
        this.resize();
        this.animate();

        window.addEventListener('resize', () => this.resize());
        this.canvas.addEventListener('mousedown', e => this.onMouseDown(e));
        this.canvas.addEventListener('mousemove', e => this.onMouseMove(e));
        window.addEventListener('mouseup', () => this.isDragging = false);
        this.canvas.addEventListener('wheel', e => this.onWheel(e), {passive: false});
        
        window.addEventListener('keydown', e => {
            if(e.code === 'Space') this.toggleSim();
            if(e.code === 'KeyR') this.resetParticles();
        });
    }

    initDOM() {
        document.getElementById('btn-start').onclick = () => this.toggleSim();
        document.getElementById('btn-reset').onclick = () => this.resetParticles();
        document.getElementById('btn-view-reset').onclick = () => this.resetView(); 
        
        document.getElementById('btn-add-particle').onclick = () => this.addParticle();
        document.getElementById('btn-add-field').onclick = () => this.addField();
        
        document.getElementById('sim-speed').oninput = (e) => {
            const baseSteps = 100;
            this.physics.stepsPerFrame = baseSteps + parseInt(e.target.value) * 15;
        };
        
        document.getElementById('trail-interval').onchange = (e) => {
            this.trailClearInterval = parseInt(e.target.value);
        };

        this.toggleFieldInputs();
        this.toggleShapeInputs();
        this.toggleParticleInputMode();
        this.handlePresetChange();
    }

    switchTab(tabName) {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        if(tabName === 'controls') {
            document.querySelector('.tab-btn:nth-child(1)').classList.add('active');
            document.getElementById('tab-controls').classList.add('active');
        } else {
            document.querySelector('.tab-btn:nth-child(2)').classList.add('active');
            document.getElementById('tab-manage').classList.add('active');
            this.renderLists();
        }
    }

    // ====== 场景系统：UI生成与加载 ======

    setupSceneUI(type) {
        const panel = document.getElementById('scene-params-panel');
        const container = document.getElementById('scene-inputs');
        const title = document.getElementById('scene-title');
        
        panel.style.display = 'block';
        container.innerHTML = ''; 
        this.currentSceneType = type;

        let inputsHTML = '';

        if (type === 'velocity_selector') {
            title.innerText = "速度选择器参数";
            inputsHTML += this.createInput('sc-x', '起始中心 X (m)', -0.2, 0.01);
            inputsHTML += this.createInput('sc-y', '起始中心 Y (m)', 0, 0.01);
            
            inputsHTML += this.createInput('sc-v', '目标速度 (m/s)', 200000);
            inputsHTML += this.createInput('sc-b', '磁场 B (T)', 0.05, 0.001);
        } 
        else {
            if (type === 'dynamic_rotation') title.innerText = "旋转圆参数 (全屏场)";
            else if (type === 'dynamic_translation') title.innerText = "平移圆参数 (全屏场)";
            else if (type === 'dynamic_scaling') title.innerText = "放缩圆参数 (全屏场)";

            // 粒子源位置
            inputsHTML += this.createInput('sc-x', '粒子源位置 X (m)', -0.1, 0.01);
            inputsHTML += this.createInput('sc-y', '粒子源位置 Y (m)', 0, 0.01);

            inputsHTML += this.createInput('sc-v', '基准速度 (m/s)', 100000);
            inputsHTML += this.createInput('sc-b', '磁场 B (T)', 0.02, 0.001);
            
            if (type === 'dynamic_rotation') inputsHTML += this.createInput('sc-step', '角度间隔 (°)', 15);
            else if (type === 'dynamic_translation') inputsHTML += this.createInput('sc-step', '间距间隔 (m)', 0.04, 0.01);
            else if (type === 'dynamic_scaling') inputsHTML += this.createInput('sc-step', '速度倍率增量', 0.2, 0.1);
        }

        container.innerHTML = inputsHTML;
        this.reloadCurrentScene();
    }

    createInput(id, label, val, step=null) {
        return `
        <div class="input-row">
            <label>${label}:</label>
            <input type="number" id="${id}" value="${val}" ${step ? `step="${step}"` : ''}>
        </div>`;
    }

    reloadCurrentScene() {
        if (!this.currentSceneType) return;
        
        this.clearAll();
        this.isRunning = false;
        document.getElementById('status-state').innerText = "状态: 停止";
        
        const getVal = (id) => parseFloat(document.getElementById(id).value);
        
        const type = this.currentSceneType;
        const proton = PRESETS.proton;
        const rectW_Selector = 0.4, rectH_Selector = 0.2;
        const colors = ['#FF5252', '#FFEB3B', '#448AFF', '#69F0AE', '#E040FB'];
        
        const startX = getVal('sc-x');
        const startY = getVal('sc-y');

        if (type === 'velocity_selector') {
            const v = getVal('sc-v');
            const B = getVal('sc-b');
            const E = v * B; 

            const centerX = startX + rectW_Selector / 2;
            const centerY = 0;

            const magRegion = new RectRegion(this.physics.nextId++, 'magnetic', centerX, centerY, rectW_Selector, rectH_Selector, 0);
            magRegion.Bz = -B; 
            this.physics.addRegion(magRegion);

            const elecRegion = new RectRegion(this.physics.nextId++, 'electric', centerX, centerY, rectW_Selector, rectH_Selector, 0);
            elecRegion.Ex = 0;
            elecRegion.Ey = -E; 
            this.physics.addRegion(elecRegion);

            const p = new Particle(this.physics.nextId++, startX, startY, v, 0, proton, '#FF9800');
            p.label = "v=E/B";
            this.physics.addParticle(p);

            const pFast = new Particle(this.physics.nextId++, startX, startY + 0.02, v*1.5, 0, proton, '#9E9E9E');
            pFast.label = "v_high";
            this.physics.addParticle(pFast);

             const pSlow = new Particle(this.physics.nextId++, startX, startY - 0.02, v*0.7, 0, proton, '#607D8B');
            pSlow.label = "v_low";
            this.physics.addParticle(pSlow);
        }
        else {
            const vBase = getVal('sc-v');
            const B = getVal('sc-b');
            const step = getVal('sc-step');
            
            // 使用全屏场
            const fieldR = new UniformRegion(this.physics.nextId++, 'magnetic');
            fieldR.Bz = -B; 
            this.physics.addRegion(fieldR);

            if (type === 'dynamic_rotation') {
                const angles = [-2*step, -step, 0, step, 2*step];
                angles.forEach((ang, i) => {
                    const rad = ang * Math.PI / 180;
                    const vx = vBase * Math.cos(rad);
                    const vy = vBase * Math.sin(rad);
                    const p = new Particle(this.physics.nextId++, startX, startY, vx, vy, proton, colors[i%5]);
                    p.label = `${ang}°`;
                    this.physics.addParticle(p);
                });
            }
            else if (type === 'dynamic_translation') {
                const ys = [2*step, step, 0, -step, -2*step];
                ys.forEach((yOffset, i) => {
                    const p = new Particle(this.physics.nextId++, startX, startY + yOffset, vBase, 0, proton, colors[i%5]);
                    p.label = `y${yOffset > 0 ? '+' : ''}${yOffset}`;
                    this.physics.addParticle(p);
                });
            }
            else if (type === 'dynamic_scaling') {
                const factors = [1 - 2*step, 1 - step, 1, 1 + step, 1 + 2*step];
                factors.forEach((f, i) => {
                    if(f <= 0) return;
                    const v = vBase * f;
                    const p = new Particle(this.physics.nextId++, startX, startY, v, 0, proton, colors[i%5]);
                    p.label = `v×${f.toFixed(1)}`;
                    this.physics.addParticle(p);
                });
            }
        }

        this.renderLists();
        this.scale = 1500;
        this.draw();
    }

    // ====== 视图与其他功能 ======

    changeViewMode(mode) {
        this.viewMode = mode;
        this.draw();
    }

    toggleParticleInputMode() {
        const mode = document.getElementById('p-pos-mode').value;
        document.getElementById('p-input-cartesian').style.display = mode === 'cartesian' ? 'block' : 'none';
        document.getElementById('p-input-polar').style.display = mode === 'polar' ? 'block' : 'none';
    }

    toggleFieldInputs() {
        const isMag = document.getElementById('field-type').value === 'magnetic';
        document.getElementById('magnetic-inputs').style.display = isMag ? 'block' : 'none';
        document.getElementById('electric-inputs').style.display = isMag ? 'none' : 'block';
    }

    toggleShapeInputs() {
        const shape = document.getElementById('region-shape').value;
        document.querySelectorAll('.dynamic-input-group').forEach(el => el.classList.remove('active'));
        this.handlePresetChange();
        
        if (shape !== 'uniform') {
            document.getElementById(`shape-${shape}`).classList.add('active');
        }
    }

    resize() {
        this.canvas.width = document.getElementById('main-area').clientWidth;
        this.canvas.height = document.getElementById('main-area').clientHeight;
        if (!this.offsetX) this.resetView(); 
    }

    resetView() {
        this.scale = 2000;
        this.offsetX = this.canvas.width / 2;
        this.offsetY = this.canvas.height / 2;
        this.draw();
    }

    w2s(wx, wy) {
        return { x: wx * this.scale + this.offsetX, y: this.offsetY - wy * this.scale };
    }
    s2w(sx, sy) {
        return { x: (sx - this.offsetX) / this.scale, y: (this.offsetY - sy) / this.scale };
    }

    toggleSim() {
        this.isRunning = !this.isRunning;
        document.getElementById('status-state').innerText = this.isRunning ? "状态: 运行中" : "状态: 停止";
    }

    resetParticles() {
        this.physics.particles = [];
        this.highlightedParticleId = null;
        this.frameCount = 0;
        this.renderLists();
        this.updateMonitor();
    }

    clearAll() {
        this.physics.particles = [];
        this.physics.regions = [];
        this.highlightedParticleId = null;
        this.frameCount = 0;
        this.renderLists();
        this.updateMonitor();
    }

    handlePresetChange() {
        const name = document.getElementById('particle-preset').value;
        
        const customProps = document.getElementById('custom-particle-props');
        if (name === 'custom') {
            customProps.classList.add('active');
        } else {
            customProps.classList.remove('active');
        }

        this.loadPreset(name);
    }

    loadPreset(name) {
        if (name === 'custom') return;
        let v0 = 2e6;
        if (name === 'proton') v0 = 5e4;
        if (name === 'alpha') v0 = 3e4;
        document.getElementById('p-velocity').value = v0;
    }

    addParticle() {
        const type = document.getElementById('particle-preset').value;
        let config = PRESETS[type];
        
        if (type === 'custom') {
             const qVal = parseFloat(document.getElementById('custom-q').value);
             const mVal = parseFloat(document.getElementById('custom-m').value);
             config = {
                 q: qVal,
                 m: mVal,
                 radius: 4,
                 label: 'Custom'
             };
        }
        
        const v0 = parseFloat(document.getElementById('p-velocity').value);
        const angleV = parseFloat(document.getElementById('p-angle').value) * Math.PI / 180;
        
        let x, y;
        const inputMode = document.getElementById('p-pos-mode').value;
        
        if (inputMode === 'cartesian') {
            x = parseFloat(document.getElementById('p-x').value);
            y = parseFloat(document.getElementById('p-y').value);
        } else {
            const r = parseFloat(document.getElementById('p-r').value);
            const theta = parseFloat(document.getElementById('p-theta').value) * Math.PI / 180;
            x = r * Math.cos(theta);
            y = r * Math.sin(theta);
        }

        const vx = v0 * Math.cos(angleV);
        const vy = v0 * Math.sin(angleV);

        let color = '#2196F3';
        if (type === 'proton') color = '#FF9800';
        else if (type === 'alpha') color = '#4CAF50';
        else if (type === 'custom') color = Utils.getRandomColor();

        const p = new Particle(this.physics.nextId++, x, y, vx, vy, config, color);
        this.physics.addParticle(p);
        this.renderLists();
        this.updateMonitor();

        this.isRunning = false;
        document.getElementById('status-state').innerText = "状态: 停止";
        this.draw(); 
    }

    addField() {
        const type = document.getElementById('field-type').value;
        const shape = document.getElementById('region-shape').value;
        
        let props = {};
        if (type === 'magnetic') {
            props.Bz = parseFloat(document.getElementById('field-b').value);
            if (document.getElementById('field-b-dir').value === 'in') props.Bz *= -1;
        } else {
            props.Ex = parseFloat(document.getElementById('field-ex').value);
            props.Ey = parseFloat(document.getElementById('field-ey').value);
        }

        let region;
        const id = this.physics.nextId++;

        if (shape === 'uniform') {
            region = new UniformRegion(id, type);
        } else if (shape === 'rect') {
            const cx = parseFloat(document.getElementById('rect-x').value);
            const cy = parseFloat(document.getElementById('rect-y').value);
            const w = parseFloat(document.getElementById('rect-w').value);
            const h = parseFloat(document.getElementById('rect-h').value);
            const angle = parseFloat(document.getElementById('rect-angle').value) * Math.PI / 180;
            region = new RectRegion(id, type, cx, cy, w, h, angle);
        } else if (shape === 'circle') {
            const cx = parseFloat(document.getElementById('circ-x').value);
            const cy = parseFloat(document.getElementById('circ-y').value);
            const r = parseFloat(document.getElementById('circ-r').value);
            region = new CircleRegion(id, type, cx, cy, r);
        }

        if (region) {
            Object.assign(region, props);
            this.physics.addRegion(region);
            this.renderLists();
        }

        this.isRunning = false;
        document.getElementById('status-state').innerText = "状态: 停止";
        this.draw(); 
    }

    renderLists() {
        const fList = document.getElementById('field-list-container');
        const pList = document.getElementById('particle-list-container');
        
        if (this.physics.regions.length === 0) fList.innerHTML = '<div style="color:#999;font-size:12px;padding:10px;">无场区域</div>';
        else {
            fList.innerHTML = this.physics.regions.map(r => {
                let info = "";
                if (r.type === 'magnetic') info = `B=${r.Bz}T`;
                else info = `E=(${r.Ex},${r.Ey})`;
                let shapeName = { rect:'矩形', circle:'圆形', uniform:'全空间' }[r.shape];
                return `
                <div id="list-item-region-${r.id}" class="list-item field-item">
                    <span>${shapeName} [${info}]</span>
                    <button class="delete-btn" onclick="app.deleteRegion(${r.id})">×</button>
                </div>`;
            }).join('');
        }

        if (this.physics.particles.length === 0) pList.innerHTML = '<div style="color:#999;font-size:12px;padding:10px;">无粒子</div>';
        else {
            pList.innerHTML = this.physics.particles.map(p => `
                <div id="list-item-particle-${p.id}" class="list-item particle-item" style="border-left-color:${p.color}">
                    <span>${p.label}</span>
                    <button class="delete-btn" onclick="app.deleteParticle(${p.id})">×</button>
                </div>
            `).join('');
        }
    }

    deleteParticle(id) {
        this.physics.removeParticle(id);
        if (this.highlightedParticleId === id) this.highlightedParticleId = null;
        this.renderLists();
        this.updateMonitor();
    }
    deleteRegion(id) {
        this.physics.removeRegion(id);
        this.renderLists();
    }
    
    highlightParticle(id) {
        this.highlightedParticleId = id;
        this.draw();
        setTimeout(() => {
             this.highlightedParticleId = null; 
             this.draw();
        }, 800);
    }

    updateMonitor() {
        const container = document.getElementById('monitor-container');
        
        if (this.physics.particles.length === 0) {
            if (container.innerHTML.indexOf("暂无活跃粒子") === -1) {
                container.innerHTML = '<div style="color:#999; font-size:12px; padding:10px;">暂无活跃粒子</div>';
            }
            return;
        }

        let html = '';
        
        this.physics.particles.forEach(p => {
            const res = this.physics.acceleration(p.pos.x, p.pos.y, p.vel.x, p.vel.y, p.q, p.m);
            const v = Math.hypot(p.vel.x, p.vel.y);
            
            html += `
            <div class="monitor-card" style="border-left-color: ${p.color}" onclick="app.highlightParticle(${p.id})">
                <div class="monitor-header">
                    <span>${p.label} <span style="font-weight:normal; font-size:10px; opacity:0.7">ID:${p.id}</span></span>
                    <button class="mini-del-btn" onclick="event.stopPropagation(); app.deleteParticle(${p.id})">×</button>
                </div>
                <div class="monitor-data">
                    <span>x: <span class="val">${p.pos.x.toExponential(2)}</span></span>
                    <span>vx: <span class="val">${p.vel.x.toExponential(2)}</span></span>
                    <span>y: <span class="val">${p.pos.y.toExponential(2)}</span></span>
                    <span>vy: <span class="val">${p.vel.y.toExponential(2)}</span></span>
                    <span>v: <span class="val">${v.toExponential(2)}</span></span>
                    <span>B: <span class="val">${res.fields.Bz.toFixed(3)}</span></span>
                </div>
            </div>`;
        });
        
        if (container.childElementCount !== this.physics.particles.length || this.frameCount % 20 === 0) {
             container.innerHTML = html;
        } else {
            container.innerHTML = html;
        }
    }

    animate() {
        if (this.isRunning) {
            for(let i=0; i<this.physics.stepsPerFrame; i++) {
                this.physics.step();
            }
            if (this.frameCount % 5 === 0) {
                this.updateMonitor();
            }
            this.frameCount++;
            if (this.frameCount >= this.trailClearInterval) {
                this.frameCount = 0;
                this.physics.particles.forEach(p => {
                    p.trail = [{x: p.pos.x, y: p.pos.y}];
                });
            }
        }
        
        this.draw();
        requestAnimationFrame(() => this.animate());
    }

    draw() {
        const ctx = this.ctx;
        ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        if (this.viewMode === 'cartesian') {
            this.drawCartesianGrid(ctx);
        } else {
            this.drawPolarGrid(ctx);
        }

        this.drawRegions(ctx);
        this.drawParticles(ctx);
    }

    drawCartesianGrid(ctx) {
        ctx.strokeStyle = '#e0e0e0';
        ctx.lineWidth = 1;
        ctx.fillStyle = "#666";
        ctx.font = "10px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "top";
        ctx.setLineDash([]); 
        
        let gridSize = 0.1; 
        while (gridSize * this.scale < 50) gridSize *= 10;
        while (gridSize * this.scale > 200) gridSize /= 10;

        const tl = this.s2w(0, 0);
        const br = this.s2w(this.canvas.width, this.canvas.height);

        const startX = Math.floor(tl.x / gridSize) * gridSize;
        const endX = Math.ceil(br.x / gridSize) * gridSize;
        const startY = Math.floor(br.y / gridSize) * gridSize; 
        const endY = Math.ceil(tl.y / gridSize) * gridSize;

        const origin = this.w2s(0, 0);

        ctx.beginPath();
        for (let x = startX; x <= endX; x += gridSize) {
            const s = this.w2s(x, 0);
            ctx.moveTo(s.x, 0);
            ctx.lineTo(s.x, this.canvas.height);
            
            if (Math.abs(x) > 1e-10) { 
                ctx.fillText(Utils.formatNumber(x), s.x, origin.y + 4);
                ctx.moveTo(s.x, origin.y);
                ctx.lineTo(s.x, origin.y + 4);
            }
        }
        ctx.stroke();

        ctx.textAlign = "right";
        ctx.textBaseline = "middle";
        ctx.beginPath();
        const minY = Math.min(startY, endY), maxY = Math.max(startY, endY);
        for (let y = minY; y <= maxY; y += gridSize) {
            const s = this.w2s(0, y);
            ctx.moveTo(0, s.y);
            ctx.lineTo(this.canvas.width, s.y);

            if (Math.abs(y) > 1e-10) { 
                ctx.fillText(Utils.formatNumber(y), origin.x - 4, s.y);
                ctx.moveTo(origin.x, s.y);
                ctx.lineTo(origin.x - 4, s.y);
            }
        }
        ctx.stroke();

        ctx.strokeStyle = '#999';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, origin.y);
        ctx.lineTo(this.canvas.width, origin.y);
        ctx.moveTo(origin.x, 0);
        ctx.lineTo(origin.x, this.canvas.height);
        ctx.stroke();

        ctx.fillText("0", origin.x - 4, origin.y + 4);
    }

    drawPolarGrid(ctx) {
        ctx.strokeStyle = '#e0e0e0';
        ctx.lineWidth = 1;
        ctx.fillStyle = "#888";
        ctx.font = "10px sans-serif";
        ctx.setLineDash([]); 

        const origin = this.w2s(0, 0);
        const maxR = Math.max(this.canvas.width, this.canvas.height) / this.scale * 1.5;

        let rStep = 0.1;
        while (rStep * this.scale < 50) rStep *= 10;
        while (rStep * this.scale > 200) rStep /= 10;

        ctx.beginPath();
        ctx.textAlign = "left";
        ctx.textBaseline = "bottom";
        for (let r = rStep; r < maxR; r += rStep) {
            const screenR = r * this.scale;
            ctx.moveTo(origin.x + screenR, origin.y);
            ctx.arc(origin.x, origin.y, screenR, 0, Math.PI * 2);
            ctx.fillText(Utils.formatNumber(r), origin.x + screenR + 2, origin.y - 2);
        }
        ctx.stroke();

        ctx.beginPath();
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const maxScreenDim = Math.max(this.canvas.width, this.canvas.height);
        for (let ang = 0; ang < 360; ang += 30) {
            const rad = ang * Math.PI / 180;
            const endX = origin.x + Math.cos(rad) * maxScreenDim * 2;
            const endY = origin.y - Math.sin(rad) * maxScreenDim * 2;
            
            ctx.moveTo(origin.x, origin.y);
            ctx.lineTo(endX, endY);

            const textR = Math.min(this.canvas.width, this.canvas.height) * 0.45;
            const tx = origin.x + Math.cos(rad) * textR;
            const ty = origin.y - Math.sin(rad) * textR;
            ctx.fillText(ang + "°", tx, ty);
        }
        ctx.stroke();

        ctx.fillStyle = '#666';
        ctx.beginPath();
        ctx.arc(origin.x, origin.y, 3, 0, Math.PI*2);
        ctx.fill();
    }

    drawRegions(ctx) {
        ctx.setLineDash([]); 
        for (let r of this.physics.regions) {
            ctx.save();
            ctx.fillStyle = r.type === 'magnetic' ? 'rgba(33, 150, 243, 0.2)' : 'rgba(255, 193, 7, 0.2)';
            ctx.strokeStyle = r.type === 'magnetic' ? '#2196F3' : '#FFC107';
            ctx.lineWidth = 2;

            if (r.shape === 'uniform') {
                ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
            } 
            else if (r.shape === 'rect') {
                const center = this.w2s(r.cx, r.cy);
                ctx.translate(center.x, center.y);
                ctx.rotate(r.angle); 
                ctx.beginPath();
                ctx.rect(-r.w * this.scale / 2, -r.h * this.scale / 2, r.w * this.scale, r.h * this.scale);
                ctx.fill();
                ctx.stroke();
                ctx.rotate(-r.angle);
                this.drawFieldSymbol(ctx, 0, 0, r);
            } 
            else if (r.shape === 'circle') {
                const center = this.w2s(r.cx, r.cy);
                ctx.beginPath();
                ctx.arc(center.x, center.y, r.r * this.scale, 0, Math.PI*2);
                ctx.fill();
                ctx.stroke();
                this.drawFieldSymbol(ctx, center.x, center.y, r);
            }
            ctx.restore();
        }
    }

    drawFieldSymbol(ctx, x, y, r) {
        ctx.fillStyle = ctx.strokeStyle;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        let symbol = "E";
        if (r.type === 'magnetic') symbol = r.Bz < 0 ? "×" : "•"; 
        ctx.font = "16px Arial";
        ctx.fillText(symbol, x, y);
    }

    drawParticles(ctx) {
        for (let p of this.physics.particles) {
            if (p.trail.length > 1) {
                ctx.beginPath();
                ctx.strokeStyle = p.color;
                ctx.lineWidth = 2;
                ctx.setLineDash([4, 4]); 
                ctx.globalAlpha = 0.6;
                for (let i = 0; i < p.trail.length; i++) {
                    const pos = this.w2s(p.trail[i].x, p.trail[i].y);
                    if (i === 0) ctx.moveTo(pos.x, pos.y);
                    else ctx.lineTo(pos.x, pos.y);
                }
                ctx.stroke();
                ctx.globalAlpha = 1.0;
                ctx.setLineDash([]);
            }

            const pos = this.w2s(p.pos.x, p.pos.y);
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, p.radius, 0, Math.PI*2);
            ctx.fillStyle = p.color;
            ctx.fill();

            if (this.highlightedParticleId === p.id) {
                ctx.beginPath();
                ctx.arc(pos.x, pos.y, p.radius * 3, 0, Math.PI*2);
                ctx.strokeStyle = '#FFEB3B';
                ctx.lineWidth = 3;
                ctx.stroke();
            }

            const vMag = Math.hypot(p.vel.x, p.vel.y);
            if (vMag > 1e-10) {
                const arrowLen = 35; 
                const angle = Math.atan2(-p.vel.y, p.vel.x); 
                
                const endX = pos.x + Math.cos(angle) * arrowLen;
                const endY = pos.y + Math.sin(angle) * arrowLen;

                ctx.beginPath();
                ctx.moveTo(pos.x, pos.y);
                ctx.lineTo(endX, endY);
                ctx.strokeStyle = '#455A64';
                ctx.lineWidth = 1.5;
                ctx.stroke();

                const headLen = 8;
                ctx.beginPath();
                ctx.moveTo(endX, endY);
                ctx.lineTo(endX - headLen * Math.cos(angle - Math.PI/6), endY - headLen * Math.sin(angle - Math.PI/6));
                ctx.lineTo(endX - headLen * Math.cos(angle + Math.PI/6), endY - headLen * Math.sin(angle + Math.PI/6));
                ctx.fillStyle = '#455A64';
                ctx.fill();
            }
        }
    }

    onMouseDown(e) {
        this.isDragging = true;
        this.lastMouse = { x: e.clientX, y: e.clientY };

        const rect = this.canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left;
        const my = e.clientY - rect.top;
        const wPos = this.s2w(mx, my);

        let clickedRegionId = null;
        for (let i = this.physics.regions.length - 1; i >= 0; i--) {
            const r = this.physics.regions[i];
            if (r.contains(wPos.x, wPos.y)) {
                clickedRegionId = r.id;
                break;
            }
        }

        if (clickedRegionId !== null) {
            this.highlightObjectInList(clickedRegionId);
        }
    }

    highlightObjectInList(id) {
        this.switchTab('manage');
        setTimeout(() => {
            const el = document.getElementById(`list-item-region-${id}`);
            if (el) {
                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                el.style.backgroundColor = "#ffe082";
                setTimeout(() => el.style.backgroundColor = "", 1000);
            }
        }, 50);
    }

    onMouseMove(e) {
        const rect = this.canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left;
        const my = e.clientY - rect.top;
        const wPos = this.s2w(mx, my);

        let coordText = "";
        const r = Math.hypot(wPos.x, wPos.y);
        let theta = Math.atan2(wPos.y, wPos.x) * 180 / Math.PI;
        if (theta < 0) theta += 360;

        if (this.viewMode === 'cartesian') {
            coordText = `(x=${wPos.x.toFixed(3)}, y=${wPos.y.toFixed(3)})`;
        } else {
            coordText = `(r=${r.toFixed(3)}, θ=${theta.toFixed(1)}°)`;
        }
        document.getElementById('status-mouse').innerText = `鼠标: ${coordText}`;

        if (this.isDragging) {
            const dx = e.clientX - this.lastMouse.x;
            const dy = e.clientY - this.lastMouse.y;
            this.offsetX += dx;
            this.offsetY += dy;
            this.lastMouse = { x: e.clientX, y: e.clientY };
            this.draw(); 
        }
    }

    onWheel(e) {
        e.preventDefault();
        const zoomRate = 0.1;
        const delta = e.deltaY > 0 ? (1 - zoomRate) : (1 + zoomRate);
        
        const rect = this.canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left;
        const my = e.clientY - rect.top;
        const worldBefore = this.s2w(mx, my);

        this.scale *= delta;
        this.scale = Math.max(1, Math.min(this.scale, 1e8));

        this.offsetX = mx - worldBefore.x * this.scale;
        this.offsetY = my + worldBefore.y * this.scale;

        const unit = this.scale;
        document.getElementById('status-scale').innerText = `比例: 1px ≈ ${(1/unit).toExponential(1)}m`;
        
        this.draw();
    }
}