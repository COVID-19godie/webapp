/* =================== 数据模型 =================== */

class Region {
    constructor(id, type, shape) {
        this.id = id;
        this.type = type; 
        this.shape = shape; 
    }
    contains(px, py) { return false; }
}

class RectRegion extends Region {
    constructor(id, type, x, y, w, h, angle) {
        super(id, type, 'rect');
        this.cx = x; this.cy = y; this.w = w; this.h = h; this.angle = angle;
    }
    contains(px, py) {
        const p = Utils.rotatePoint(px, py, this.cx, this.cy, -this.angle);
        return p.x >= this.cx - this.w/2 && p.x <= this.cx + this.w/2 &&
               p.y >= this.cy - this.h/2 && p.y <= this.cy + this.h/2;
    }
}

class CircleRegion extends Region {
    constructor(id, type, x, y, r) {
        super(id, type, 'circle');
        this.cx = x; this.cy = y; this.r = r;
    }
    contains(px, py) {
        return (px - this.cx)**2 + (py - this.cy)**2 <= this.r**2;
    }
}

class UniformRegion extends Region {
    constructor(id, type) { super(id, type, 'uniform'); }
    contains(px, py) { return true; }
}

class Particle {
    constructor(id, x, y, vx, vy, config, color) {
        this.id = id;
        this.pos = { x: x, y: y };
        this.vel = { x: vx, y: vy };
        this.q = config.q;
        this.m = config.m;
        this.radius = config.radius;
        this.label = config.label;
        this.color = color;
        this.trail = [];
        this.active = true;
    }

    updateTrail() {
        if (this.trail.length === 0) {
            this.trail.push({x: this.pos.x, y: this.pos.y});
            return;
        }
        const last = this.trail[this.trail.length-1];
        const distSq = (this.pos.x - last.x)**2 + (this.pos.y - last.y)**2;
        if (distSq > 1e-7) { 
            this.trail.push({x: this.pos.x, y: this.pos.y});
            if (this.trail.length > 20000) this.trail.shift();
        }
    }
}

/* =================== 物理引擎 =================== */

class PhysicsEngine {
    constructor() {
        this.particles = [];
        this.regions = [];
        this.dt = 2e-12; 
        this.stepsPerFrame = 500; 
        this.nextId = 1;
    }

    addParticle(p) { this.particles.push(p); }
    addRegion(r) { this.regions.push(r); }
    removeParticle(id) { this.particles = this.particles.filter(p => p.id !== id); }
    removeRegion(id) { this.regions = this.regions.filter(r => r.id !== id); }

    calculateFields(x, y) {
        let Bz = 0, Ex = 0, Ey = 0;
        for (let r of this.regions) {
            if (r.contains(x, y)) {
                if (r.type === 'magnetic') Bz += r.Bz;
                else if (r.type === 'electric') { Ex += r.Ex; Ey += r.Ey; }
            }
        }
        return { Bz, Ex, Ey };
    }

    acceleration(x, y, vx, vy, q, m) {
        const { Bz, Ex, Ey } = this.calculateFields(x, y);
        return {
            ax: (q / m) * (Ex + vy * Bz),
            ay: (q / m) * (Ey - vx * Bz),
            fields: { Bz, Ex, Ey }
        };
    }

    step() {
        const dt = this.dt;
        for (let p of this.particles) {
            if (!p.active) continue;

            const {x, y} = p.pos;
            const {x: vx, y: vy} = p.vel;

            let a1 = this.acceleration(x, y, vx, vy, p.q, p.m);
            let k1_vx = a1.ax * dt, k1_vy = a1.ay * dt;
            let k1_rx = vx * dt, k1_ry = vy * dt;

            let a2 = this.acceleration(x + k1_rx/2, y + k1_ry/2, vx + k1_vx/2, vy + k1_vy/2, p.q, p.m);
            let k2_vx = a2.ax * dt, k2_vy = a2.ay * dt;
            let k2_rx = (vx + k1_vx/2) * dt, k2_ry = (vy + k1_vy/2) * dt;

            let a3 = this.acceleration(x + k2_rx/2, y + k2_ry/2, vx + k2_vx/2, vy + k2_vy/2, p.q, p.m);
            let k3_vx = a3.ax * dt, k3_vy = a3.ay * dt;
            let k3_rx = (vx + k2_vx/2) * dt, k3_ry = (vy + k2_vy/2) * dt;

            let a4 = this.acceleration(x + k3_rx, y + k3_ry, vx + k3_vx, vy + k3_vy, p.q, p.m);
            let k4_vx = a4.ax * dt, k4_vy = a4.ay * dt;
            let k4_rx = (vx + k3_vx) * dt, k4_ry = (vy + k3_vy) * dt;

            p.pos.x += (k1_rx + 2*k2_rx + 2*k3_rx + k4_rx) / 6;
            p.pos.y += (k1_ry + 2*k2_ry + 2*k3_ry + k4_ry) / 6;
            p.vel.x += (k1_vx + 2*k2_vx + 2*k3_vx + k4_vx) / 6;
            p.vel.y += (k1_vy + 2*k2_vy + 2*k3_vy + k4_vy) / 6;

            p.updateTrail();
        }
    }
}